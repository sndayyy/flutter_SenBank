class TransactionModel {
  final String title;
  final String amount;
  final String category;

  TransactionModel(this.title, this.amount, this.category);
}
